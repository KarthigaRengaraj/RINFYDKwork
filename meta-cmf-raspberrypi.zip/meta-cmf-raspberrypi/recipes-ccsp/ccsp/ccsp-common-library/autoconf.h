#define CONFIG_VENDOR_NAME "Raspberry Pi Foundation"
#define CONFIG_VENDOR_ID "0xFFFFFFFF"
#define CONFIG_TI_GW_DESCRIPTION "Raspberry Pi 3 device"

